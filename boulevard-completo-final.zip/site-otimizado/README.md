# Boulevard Butantã - Site Otimizado

Site de imóvel com todas as imagens em WebP otimizadas para máxima performance.

## 📁 Estrutura do Projeto

```
boulevard-butanta/
├── index.html          ← Arquivo principal (13 KB)
└── imagens/            ← Todas as imagens WebP
    ├── 01-04: CAD Slide (Edifício)
    ├── 05-12: Apartamento Decorado
    ├── 13-21: Área de Lazer
    ├── 22-25: Localização
    └── 26-31: Visite Seu Apartamento
```

## 🚀 Como Usar

### Local (seu computador)
1. Extraia o arquivo ZIP
2. Abra `index.html` no navegador
3. Pronto! Todas as imagens aparecem

### GitHub Pages
1. Crie um repositório no GitHub
2. Faça upload de todos os arquivos (mantendo a estrutura)
3. Vá em Settings → Pages → Source: main branch
4. Seu site estará em: `https://seu-usuario.github.io/boulevard-butanta`

### Hospedagem Web
1. FTP/Upload todos os arquivos
2. Mantenha a pasta `imagens/` na mesma pasta do `index.html`
3. Pronto!

## ⚡ Performance

- **HTML**: 13 KB (super otimizado)
- **Imagens**: 31 arquivos WebP (5.9 MB total)
- **Carregamento**: Muito rápido com lazy loading
- **Responsivo**: Funciona em celular, tablet e desktop

## 📋 Blocos do Site

1. **Hero** - Apresentação do empreendimento
2. **CAD Slide** - Arquitetura e perspectivas
3. **Apartamentos Decorados** - Ambientes de 83-134m²
4. **Área de Lazer** - Piscina, playground, academia, etc
5. **Localização** - 240 passos do Metrô, perto de Faria Lima
6. **Visite Seu Apartamento** - Chamada para ação
7. **Footer** - Contato e informações

## 📞 Contato

- **Telefone**: (11) 96099-8000
- **Email**: gerente.siqueira@gmail.com
- **Site**: www.dialogobutanta.com.br
- **Endereço**: Rua Dráusio, 150 - Butantã, SP

## ✨ Melhorias Implementadas

✅ Removeu 4MB de Base64 do HTML  
✅ Imagens em WebP (80% menor)  
✅ Lazy loading automático  
✅ CSS otimizado e limpo  
✅ HTML semântico e acessível  
✅ Responsivo mobile-first  
✅ Pronto para produção  

---

**Desenvolvido em**: 21 de Setembro de 2026  
**Otimizado por**: Claude AI  
**Status**: ✅ Pronto para publicar
